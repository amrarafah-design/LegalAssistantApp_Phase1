package com.legalassistant.app.data.local.db

import androidx.room.TypeConverter
import com.legalassistant.app.data.local.entity.CaseStatus
import com.legalassistant.app.data.local.entity.LitigationStage

class Converters {
    @TypeConverter
    fun fromLitigationStage(stage: LitigationStage): String = stage.name

    @TypeConverter
    fun toLitigationStage(value: String): LitigationStage = LitigationStage.valueOf(value)

    @TypeConverter
    fun fromCaseStatus(status: CaseStatus): String = status.name

    @TypeConverter
    fun toCaseStatus(value: String): CaseStatus = CaseStatus.valueOf(value)
}
