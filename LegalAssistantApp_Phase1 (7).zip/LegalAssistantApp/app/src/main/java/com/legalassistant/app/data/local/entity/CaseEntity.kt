package com.legalassistant.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

/** درجات التقاضي — ميزة تنافسية غائبة في أغلب التطبيقات المشابهة */
enum class LitigationStage {
    FIRST_INSTANCE,   // أول درجة
    APPEAL,           // استئناف
    CASSATION         // نقض
}

enum class CaseStatus {
    ACTIVE,      // جارية
    ADJOURNED,   // مؤجلة
    JUDGED,      // محكومة
    CLOSED       // مغلقة
}

@Entity(tableName = "cases")
data class CaseEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val caseNumber: String,
    val court: String,
    val litigationStage: LitigationStage,
    val caseType: String,
    val clientName: String,
    val opponentName: String,
    val status: CaseStatus,
    val nextHearingDate: Long? = null,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
