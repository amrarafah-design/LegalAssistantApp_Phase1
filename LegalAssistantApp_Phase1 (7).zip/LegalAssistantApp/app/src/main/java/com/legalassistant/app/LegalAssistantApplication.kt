package com.legalassistant.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class LegalAssistantApplication : Application()
