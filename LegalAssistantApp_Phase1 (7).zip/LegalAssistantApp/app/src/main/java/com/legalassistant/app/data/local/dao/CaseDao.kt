package com.legalassistant.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.legalassistant.app.data.local.entity.CaseEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CaseDao {

    @Query("SELECT * FROM cases ORDER BY nextHearingDate ASC")
    fun getAllCases(): Flow<List<CaseEntity>>

    @Query("SELECT * FROM cases WHERE id = :caseId")
    suspend fun getCaseById(caseId: String): CaseEntity?

    @Query("""
        SELECT * FROM cases 
        WHERE caseNumber LIKE '%' || :query || '%' 
           OR clientName LIKE '%' || :query || '%'
           OR opponentName LIKE '%' || :query || '%'
        ORDER BY nextHearingDate ASC
    """)
    fun searchCases(query: String): Flow<List<CaseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCase(case: CaseEntity)

    @Update
    suspend fun updateCase(case: CaseEntity)

    @Delete
    suspend fun deleteCase(case: CaseEntity)
}
