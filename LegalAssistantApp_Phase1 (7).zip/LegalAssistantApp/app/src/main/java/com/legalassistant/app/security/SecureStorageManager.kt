package com.legalassistant.app.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.SecureRandom
import javax.inject.Inject
import javax.inject.Singleton

/**
 * يدير تخزين كلمة مرور قاعدة البيانات المشفرة (SQLCipher) بأمان
 * باستخدام Android Keystore، بدل كتابتها كنص ثابت في الكود (Hardcoded).
 */
@Singleton
class SecureStorageManager @Inject constructor(
    context: Context
) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val encryptedPrefs = EncryptedSharedPreferences.create(
        context,
        "secure_legal_data",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    /** يُنشئ كلمة مرور عشوائية لقاعدة البيانات عند أول تشغيل، ويحفظها مشفّرة */
    fun getOrCreateDatabasePassphrase(): CharArray {
        val existing = encryptedPrefs.getString(KEY_DB_PASSPHRASE, null)
        if (existing != null) return existing.toCharArray()

        val randomBytes = ByteArray(32)
        SecureRandom().nextBytes(randomBytes)
        val newPassphrase = randomBytes.joinToString("") { "%02x".format(it) }

        encryptedPrefs.edit().putString(KEY_DB_PASSPHRASE, newPassphrase).apply()
        return newPassphrase.toCharArray()
    }

    fun saveSecret(key: String, value: String) {
        encryptedPrefs.edit().putString(key, value).apply()
    }

    fun getSecret(key: String): String? = encryptedPrefs.getString(key, null)

    companion object {
        private const val KEY_DB_PASSPHRASE = "db_passphrase_v1"
    }
}
