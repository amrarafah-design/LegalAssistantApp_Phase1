package com.legalassistant.app.ui.cases

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.legalassistant.app.R
import com.legalassistant.app.data.local.entity.CaseEntity
import com.legalassistant.app.data.local.entity.CaseStatus
import com.legalassistant.app.data.local.entity.LitigationStage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CaseListScreen(
    viewModel: CaseListViewModel = hiltViewModel(),
    onAddCaseClick: () -> Unit = {},
    onCaseClick: (CaseEntity) -> Unit = {}
) {
    val cases by viewModel.cases.collectAsState()
    var searchText by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(stringResourceAr(R.string.case_list_title)) })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddCaseClick) {
                Icon(Icons.Default.Add, contentDescription = stringResourceAr(R.string.add_new_case))
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = searchText,
                onValueChange = {
                    searchText = it
                    viewModel.onSearchQueryChanged(it)
                },
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                placeholder = { Text("ابحث برقم القضية أو اسم الموكل") },
                singleLine = true
            )

            if (cases.isEmpty()) {
                EmptyState()
            } else {
                LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
                    items(cases, key = { it.id }) { case ->
                        CaseCard(case = case, onClick = { onCaseClick(case) })
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text = "لا توجد قضايا مسجلة بعد\nاضغط على (+) لإضافة قضية جديدة",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

@Composable
private fun CaseCard(case: CaseEntity, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "قضية رقم ${case.caseNumber}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                StatusChip(status = case.status)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = case.court, style = MaterialTheme.typography.bodyMedium)
            Text(text = litigationStageLabel(case.litigationStage), style = MaterialTheme.typography.bodySmall)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "الموكل: ${case.clientName}", style = MaterialTheme.typography.bodyMedium)
            Text(text = "الخصم: ${case.opponentName}", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun StatusChip(status: CaseStatus) {
    val label = when (status) {
        CaseStatus.ACTIVE -> "جارية"
        CaseStatus.ADJOURNED -> "مؤجلة"
        CaseStatus.JUDGED -> "محكومة"
        CaseStatus.CLOSED -> "مغلقة"
    }
    AssistChip(onClick = {}, label = { Text(label) })
}

private fun litigationStageLabel(stage: LitigationStage): String = when (stage) {
    LitigationStage.FIRST_INSTANCE -> "أول درجة"
    LitigationStage.APPEAL -> "استئناف"
    LitigationStage.CASSATION -> "نقض"
}

@Composable
private fun stringResourceAr(id: Int): String = androidx.compose.ui.res.stringResource(id)
