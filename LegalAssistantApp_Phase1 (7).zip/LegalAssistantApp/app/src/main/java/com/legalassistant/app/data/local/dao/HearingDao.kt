package com.legalassistant.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.legalassistant.app.data.local.entity.HearingEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface HearingDao {

    @Query("SELECT * FROM hearings WHERE caseId = :caseId ORDER BY date ASC")
    fun getHearingsForCase(caseId: String): Flow<List<HearingEntity>>

    @Query("SELECT * FROM hearings WHERE date >= :fromTime ORDER BY date ASC")
    fun getUpcomingHearings(fromTime: Long = System.currentTimeMillis()): Flow<List<HearingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertHearing(hearing: HearingEntity)

    @Delete
    suspend fun deleteHearing(hearing: HearingEntity)
}
